<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/> 
</head>
<body>

<div class="certificate-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="certificate-view">
                    <h1>Euripeon University of Bangladesh</h1>
                    <p>BSC in CSE</p>
                    {{ $details }}
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>

<?php $__env->startSection('title','CPS - Home'); ?>
<?php $__env->startSection('content'); ?>
<div class="banner-area">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6">
                <div class="banner-left">
                    <img src="assets/images/Cert.jpg" alt="certificate">
                </div>
            </div>
            <div class="col-md-6">
                <div class="banner-right">
                    <h1>Certificate Printing <br> System</h1>
                    <br>
                    <a class="btn btn-success" href="<?php echo e(url('download-certificate')); ?>">Download Now</a>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="easy-steps">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="easy-step-img">
                    <img src="assets/images/easy-step.png" alt="easy step">
                </div>
            </div>
            <div class="col-md-6">
                <div class="easy-step-content">
                    <h2>Easy Steps</h2>
                    <ul class="easy-step-list">
                        <li><i class="fa fa-check"></i> Registration</li>
                        <li><i class="fa fa-check"></i> Verify OTP</li>
                        <li><i class="fa fa-check"></i> Approve by Administrator</li>
                        <li><i class="fa fa-check"></i> Ready to Download</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
     
<script>



</script>
    
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('Pages.PageLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\server\htdocs\CPS\resources\views/Pages/Home.blade.php ENDPATH**/ ?>
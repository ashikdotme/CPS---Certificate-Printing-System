
<?php $__env->startSection('title','CPS - Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<!-- *************************************************************** -->
<!-- Start First Cards -->
<!-- *************************************************************** -->
<div class="card-group">
    <div class="card border-right">
        <div class="card-body">
            <div class="d-flex d-lg-flex d-md-block align-items-center">
                <div>
                    <div class="d-inline-flex align-items-center">
                        <h2 class="text-dark mb-1 font-weight-medium"><?php echo e($total_pending); ?></h2>
                        
                    </div>
                    <h6 class="text-muted font-weight-normal mb-0 w-100 text-truncate">Total Pending Request</h6>
                </div>
                <div class="ml-auto mt-md-3 mt-lg-0">
                    <span class="opacity-7 text-muted"><i data-feather="user-plus"></i></span>
                </div>
            </div>
        </div>
    </div>
    <div class="card border-right">
        <div class="card-body">
            <div class="d-flex d-lg-flex d-md-block align-items-center">
                <div>
                    <h2 class="text-dark mb-1 w-100 text-truncate font-weight-medium"><?php echo e($total_approve); ?></h2>
                    <h6 class="text-muted font-weight-normal mb-0 w-100 text-truncate">Total Approved
                    </h6>
                </div>
                <div class="ml-auto mt-md-3 mt-lg-0">
                    <span class="opacity-7 text-muted"><i data-feather="check"></i></span>
                </div>
            </div>
        </div>
    </div>
    <div class="card border-right">
        <div class="card-body">
            <div class="d-flex d-lg-flex d-md-block align-items-center">
                <div>
                    <div class="d-inline-flex align-items-center">
                        <h2 class="text-dark mb-1 font-weight-medium"><?php echo e($total_reject); ?></h2>
                       
                    </div>
                    <h6 class="text-muted font-weight-normal mb-0 w-100 text-truncate">Total Rejected</h6>
                </div>
                <div class="ml-auto mt-md-3 mt-lg-0">
                    <span class="opacity-7 text-muted"><i class="fa fa-times"></i></span>
                </div>
            </div>
        </div>
    </div>
    
</div>
<!-- *************************************************************** -->
<!-- End First Cards -->
<!-- *************************************************************** -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.App', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\server\htdocs\CPS\resources\views/Dashboard.blade.php ENDPATH**/ ?>